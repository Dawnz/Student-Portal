export interface CourseWork {
  courseWorkId: number | null;
  courseId: number;
  name: string;
  grade: string | null;
}
