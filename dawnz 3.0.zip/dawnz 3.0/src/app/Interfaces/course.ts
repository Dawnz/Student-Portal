export interface Course {
  courseId: number | null;
  name: string;
  content: string;
  tutorId: number;
}
