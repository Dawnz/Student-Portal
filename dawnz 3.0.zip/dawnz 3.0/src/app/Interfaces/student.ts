export interface Student {
  studentId: number | null;
  firstName: string;
  lastName: string;
  username: string;
  password: string;
}
